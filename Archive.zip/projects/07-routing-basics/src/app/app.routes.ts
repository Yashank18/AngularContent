import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    // add a default path to greetings component
  },
];
