import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template: ` <h1>User Listing</h1> `,
})
export class AppComponent {
  constructor() {}
}
