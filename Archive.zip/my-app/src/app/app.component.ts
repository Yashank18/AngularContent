import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, NgZone } from '@angular/core';
import { RouterOutlet } from '@angular/router'

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
   <h1 i18n="pageTitle|Title for the home page">Welcome to our site!</h1>

   <div [@boxState]='buttonState' (click)="toggle()" >Animate me</div>

  {{value}}

  `,
  animations: [
    trigger('boxState', [
      state('open', style({ height: '200px', opacity: 1, backgroundColor: 'yellow' })),
      state('closed', style({ height: '100px', opacity: 0.3, backgroundColor: 'red' })),
      transition('open <=> closed', animate('300ms ease-in-out')),
    ])
  ]
})
export class AppComponent {
  title = 'my-app';
  buttonState = 'open';

  constructor(private ngZone: NgZone) { }

  value = 0;
  toggle() {
    console.log('Toggling animation'); // Test log
    this.buttonState = this.buttonState === 'open' ? 'closed' : 'open';
    // This will trigger change detection
    this.ngZone.runOutsideAngular(() => {
      this.value++;
    })
  }
}
