import { Injectable } from '@angular/core';
import { data, User } from './data';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private userData: User[] = data;

  // Want to fet placeholder data
  private apiUrl = 'https://jsonplaceholder.typicode.com/users';

  constructor(private http: HttpClient) {
  }

  // getData

  getData(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getUserData(): Promise<User[]> {
    return new Promise((resolve) => {
      resolve(this.userData);
    });
  }

  getUserById(id: number): Promise<User> {
    return new Promise((resolve) => {
      const user = this.userData.find((user) => user.id === id);
      resolve(user as User);
    })
  }

  // updateData()
  // FindDataById()
  // DeleteEntry()
}
