import { Component, inject } from '@angular/core';
import { UserService } from './user.service';
import { User } from './data';
import { UserInfoComponent } from './user-info/user-info.component';
import { trigger, state, style, animate, transition } from '@angular/animations';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [UserInfoComponent],
  animations: [
    trigger('boxState', [
      state('open', style({
        height: '200px',
        opacity: 1,
        backgroundColor: 'yellow'
      })),
      state('closed', style({
        height: '100px',
        opacity: 0.3,
        backgroundColor: 'red'
      })),
      state('inbetween', style({
        height: '150px',
        opacity: 0.5,
        backgroundColor: 'green'
      })),
      transition('open <=> inbetween', animate('300ms ease-in-out')),
      transition('inbetween => closed', animate('30ms ease-in')),
    ])
  ],
  template: ` 
  <h1>User Listing</h1> 
  @for(user of userData; track user.id) {
  <ax-user-info [user]="user"/>
  }

  <br/>
  <div [@boxState]='buttonState' (click)="toggle()" >Animate me</div>
  <h1 i18n="pageTitle|Title for the home page">Welcome to our site!</h1>
  `,
})
export class AppComponent {

  buttonState = 'open';

  toggle() {
    this.buttonState = this.buttonState === 'open' ? 'inbetween' : 'closed';
  }

  userService = inject(UserService);
  userData: User[] = [];

  // New clean approach
  ngOnInit(): void {
    this.userService.getData().subscribe((response) => {
      this.userData = response;
    },)
  }

}
