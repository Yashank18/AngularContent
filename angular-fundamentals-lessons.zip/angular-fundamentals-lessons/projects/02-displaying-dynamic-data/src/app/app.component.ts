import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <article class="offer">
    </article>
  `,
  styles: `
  `,
})
export class AppComponent {
  item = {
    name: 'Treasure Trove Trunk',
    price: 30,
    description:
      'Unveil a treasure trove of surprises in this delightful mystery box.',
  };
}
