import { Component } from '@angular/core';

@Component({
  selector: 'app-greetings',
  template: `<p>Hello dear learner 👋🏾</p>`,
  standalone: true,
})
export class GreetingsComponent {}
