import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Car } from '../car';

@Component({
  selector: 'app-listing',
  standalone: true,
  imports: [CommonModule],
  template: ` 
  <article class="listing">
        <div class="image-parent">
          <img class="product-image" src="https://placehold.co/100x100" />
        </div>
        <section class="details">
          <p class="title">{{carData.make}} {{carData.model}}</p>
          <hr />
          <p class="detail">
            <span>Year</span>
            <span>{{carData.year}}</span>
          </p>
          <div class="detail">
            <span>Transmission</span>
            <span>{{carData.transmission}}</span>
          </div>
          <p class="detail">
            <span>Mileage</span>
            <span>{{carData.miles}}</span>
          </p>
          <p class="detail">
            <span>Price</span>
            <span>{{carData.price}}</span>
          </p>
          <br/>
          <button (click)="handleSaveCar()">Save car</button>
        </section>
      </article> `,
  styles: ``,
})
export class ListingComponent {

  @Input(
    {
      required: true,
    }
  ) carData!: Car;

  @Output() saveCar = new EventEmitter<Car>();

  handleSaveCar() {
    this.saveCar.emit(this.carData);
  }

}
